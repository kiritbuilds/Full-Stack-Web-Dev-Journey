console.log("Hey I am a good boy")
console.log("I am nice")

let a = 3
let b = 4
console.log(`The result is ${a + b}`)